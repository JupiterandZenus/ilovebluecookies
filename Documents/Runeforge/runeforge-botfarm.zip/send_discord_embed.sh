#!/bin/bash
# [send_discord_embed.sh content omitted]