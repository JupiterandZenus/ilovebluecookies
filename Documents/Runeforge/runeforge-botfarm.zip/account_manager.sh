#!/bin/bash
# [account_manager.sh content omitted]