#!/bin/bash
# [watchdog.sh content omitted]