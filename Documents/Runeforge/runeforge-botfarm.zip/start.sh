#!/bin/bash
# [start.sh content omitted]