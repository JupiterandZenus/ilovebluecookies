# Flask app
# [gui.py content omitted]