#!/bin/bash
# [cpu_manager.sh content omitted]