#!/bin/bash
# [test_agent.sh content omitted]